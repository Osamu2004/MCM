clear,clc
a=[4	4	4	5	2	5	4	4	3	4
8	8	8	4	10	8	10	8	8	8
4	5	4	4	3	5	5	5	6	5
7	6	6	6	6	7	7	6	7	6
12	14	12	10	12	14	14	14	14	14
4	4	5	4	4	5	3	4	5	4
6	7	8	6	4	8	6	6	7	7
6	7	8	6	6	7	6	6	6	7
16	19	19	13	13	19	16	16	16	16
9	10	10	8	8	9	9	9	10	10
];
n=size(a,1);
for i=1:n
    Hmax=max(a(i,:));
    Hmin=min(a(i,:));
    for j=1:10
    a(i,j)=(a(i,j)-Hmin)/(Hmax-Hmin);
    end
    x=a(i,:);
    a(i,:)=zscore(x);
    for g=1:n
        for h=1:10
            if abs(a(g,h))<1e-6
                a(g,h)=0;
            end
        end
    end
end
    
