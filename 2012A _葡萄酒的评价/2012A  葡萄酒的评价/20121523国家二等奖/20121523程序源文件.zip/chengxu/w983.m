xx=sr;
wa=pc;
r=variance;
r=r';
wb=xx*wa;
R=sum(r);
n=size(xx,1);
m=size(xx,2);
Y=zeros(m,1);
for i=1:n
    for j=1:m
        Y(i)=Y(i)+(r(j)*wb(i,j))/R;
    end
end
wm=sort(Y,'descend');